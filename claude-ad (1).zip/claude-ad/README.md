# Claude Ad — Remotion Motion Graphics

A fully animated 30-second motion graphics ad for Claude by Anthropic.

## 🚀 Quick Start

```bash
npm install
npm run dev        # opens Remotion Studio at http://localhost:3000
```

## 🎬 Render to MP4

```bash
npx remotion render ClaudeAd out/claude-ad.mp4
```

## 📐 Specs

| Property | Value |
|----------|-------|
| Duration | 30 seconds (900 frames) |
| FPS | 30 |
| Resolution | 1920 × 1080 (Full HD) |
| Format | MP4 (H.264) |

## 🎞️ Scene Breakdown

| Scene | Frames | Time | Content |
|-------|--------|------|---------|
| Intro | 0–180 | 0–6s | Logo reveal + CLAUDE title |
| Meet | 180–360 | 6–12s | Animated orb + "Meet Claude" |
| Features | 360–540 | 12–18s | 4 feature cards with spring animations |
| Chat | 540–720 | 18–24s | Live chat UI demo |
| CTA | 720–900 | 24–30s | Try Claude Free button |

## 🎙️ Voiceover (add your own audio)

The ad includes caption overlays timed to 5 lines of voiceover.
To add audio, drop your MP3 into `public/voiceover.mp3` and add to `ClaudeAd.tsx`:

```tsx
import { Audio, staticFile } from "remotion";
<Audio src={staticFile("voiceover.mp3")} />
```

## 📁 Project Structure

```
src/
  ClaudeAd.tsx          # Main composition
  Root.tsx              # Registers composition
  Particles.tsx         # Floating particle system
  utils.ts              # Easing helpers
  scenes/
    SceneIntro.tsx      # Intro logo reveal
    SceneMeet.tsx       # Meet Claude orb scene
    SceneFeatures.tsx   # 4 feature cards
    SceneChat.tsx       # Chat UI demo
    SceneCTA.tsx        # Call-to-action
    SceneVoiceover.tsx  # Caption overlay
    SceneTransition.tsx # Fade in/out transitions
```
