import React from "react";

interface ClaudeLogoProps {
  size?: number;
  showCircle?: boolean;
  glowIntensity?: number;
  spinFrame?: number;
}

export const ClaudeLogo: React.FC<ClaudeLogoProps> = ({
  size = 160,
  showCircle = true,
  glowIntensity = 0.7,
  spinFrame,
}) => {
  // The actual Claude logo: a starburst / asterisk with 8 radiating spokes
  // Each spoke is a thick rounded line from center outward
  // Matches the coral asterisk seen on claude.ai

  const rotate = spinFrame !== undefined ? (spinFrame * 0.4) % 360 : 0;

  const markColor = showCircle ? "white" : "#CC785C";
  const strokeW = size * 0.085;
  const outerR = size * 0.36;
  const innerR = size * 0.08;
  const cx = size / 2;
  const cy = size / 2;

  // 8 spokes at 0, 22.5, 45, 67.5 ... degrees — but Claude uses ~6 uneven spokes
  // Looking at the actual screenshot: it's more like 6 spokes, unevenly spaced,
  // creating that organic starburst asterisk look
  const spokeAngles = [0, 45, 90, 135, 180, 225, 270, 315]; // 8 equal spokes

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: showCircle
          ? "linear-gradient(145deg, #D4845A 0%, #C06832 50%, #7A3A10 100%)"
          : "transparent",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: showCircle
          ? `0 0 ${size * 0.4}px rgba(204,120,92,${glowIntensity}), 0 0 ${size * 0.8}px rgba(204,120,92,${glowIntensity * 0.35})`
          : "none",
        flexShrink: 0,
      }}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        fill="none"
        style={{ position: "absolute" }}
      >
        <g transform={`rotate(${rotate}, ${cx}, ${cy})`}>
          {spokeAngles.map((angle, i) => {
            const rad = (angle * Math.PI) / 180;
            const x1 = cx + Math.cos(rad) * innerR;
            const y1 = cy + Math.sin(rad) * innerR;
            const x2 = cx + Math.cos(rad) * outerR;
            const y2 = cy + Math.sin(rad) * outerR;
            return (
              <line
                key={i}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={markColor}
                strokeWidth={strokeW}
                strokeLinecap="round"
                opacity={i % 2 === 0 ? 1 : 0.85}
              />
            );
          })}
        </g>
      </svg>
    </div>
  );
};
