import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  spring,
} from "remotion";
import { Particles } from "../Particles";
import { ClaudeLogo } from "../ClaudeLogo";

export const SceneIntro: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const bgOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });
  const circleScale = spring({ frame: frame - 10, fps, config: { damping: 80, stiffness: 120 } });
  const circleOpacity = interpolate(frame, [10, 30], [0, 1], { extrapolateRight: "clamp" });
  const textY = interpolate(frame, [40, 70], [60, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const textOpacity = interpolate(frame, [40, 65], [0, 1], { extrapolateRight: "clamp" });
  const tagY = interpolate(frame, [60, 85], [40, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const tagOpacity = interpolate(frame, [60, 80], [0, 1], { extrapolateRight: "clamp" });
  const lineWidth = interpolate(frame, [75, 105], [0, 340], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(ellipse at 50% 50%, #1a0e0a 0%, #0d0705 60%, #000000 100%)",
        opacity: bgOpacity,
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <Particles />

      {/* Soft background glow */}
      <div
        style={{
          position: "absolute",
          width: 600,
          height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(204,120,92,0.12) 0%, transparent 70%)",
          transform: `scale(${circleScale})`,
        }}
      />

      {/* Starburst logo — spins slowly */}
      <div style={{ transform: `scale(${circleScale})`, opacity: circleOpacity, marginBottom: 44 }}>
        <ClaudeLogo size={170} glowIntensity={0.75} spinFrame={frame} />
      </div>

      {/* CLAUDE wordmark */}
      <div style={{ transform: `translateY(${textY}px)`, opacity: textOpacity, textAlign: "center" }}>
        <div
          style={{
            fontSize: 110,
            fontFamily: "'Georgia', serif",
            fontWeight: 700,
            color: "#FFFFFF",
            letterSpacing: 24,
            textTransform: "uppercase",
            textShadow: "0 0 40px rgba(204,120,92,0.45)",
          }}
        >
          CLAUDE
        </div>
      </div>

      {/* Animated underline */}
      <div
        style={{
          width: lineWidth,
          height: 3,
          background: "linear-gradient(90deg, transparent, #CC785C, #E8B89A, #CC785C, transparent)",
          borderRadius: 2,
          marginTop: 10,
          marginBottom: 22,
          boxShadow: "0 0 14px rgba(204,120,92,0.7)",
        }}
      />

      {/* by Anthropic */}
      <div style={{ transform: `translateY(${tagY}px)`, opacity: tagOpacity, textAlign: "center" }}>
        <div
          style={{
            fontSize: 28,
            fontFamily: "'Georgia', serif",
            fontWeight: 300,
            color: "rgba(255,255,255,0.6)",
            letterSpacing: 10,
            textTransform: "uppercase",
          }}
        >
          by Anthropic
        </div>
      </div>
    </AbsoluteFill>
  );
};
