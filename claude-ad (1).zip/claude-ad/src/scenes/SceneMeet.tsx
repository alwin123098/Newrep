import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  spring,
} from "remotion";
import { Particles } from "../Particles";
import { ClaudeLogo } from "../ClaudeLogo";

export const SceneMeet: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const logoScale = spring({ frame: frame - 5, fps, config: { damping: 60, stiffness: 100 } });
  const titleOpacity = interpolate(frame, [20, 45], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [20, 45], [50, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const subtitleOpacity = interpolate(frame, [40, 60], [0, 1], { extrapolateRight: "clamp" });
  const ring1Scale = 1 + Math.sin(frame * 0.05) * 0.05;
  const ring2Scale = 1 + Math.sin(frame * 0.05 + 1) * 0.07;
  const voiceOpacity = interpolate(frame, [30, 50], [0, 1], { extrapolateRight: "clamp" });
  const glowPulse = interpolate(Math.sin(frame * 0.06), [-1, 1], [0.3, 0.6]);

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(ellipse at 40% 50%, #1a0e0a 0%, #0a0604 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <Particles />

      {/* Pulsing rings */}
      <div style={{ position: "absolute", display: "flex", justifyContent: "center", alignItems: "center" }}>
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              width: 200 + i * 80,
              height: 200 + i * 80,
              borderRadius: "50%",
              border: `1px solid rgba(204,120,92,${0.3 / i})`,
              transform: `scale(${i === 1 ? ring1Scale : ring2Scale})`,
            }}
          />
        ))}
      </div>

      {/* Background glow */}
      <div style={{
        position: "absolute",
        width: 500,
        height: 500,
        borderRadius: "50%",
        background: `radial-gradient(circle, rgba(204,120,92,${glowPulse}) 0%, transparent 65%)`,
        opacity: 0.3,
      }} />

      {/* Accurate Claude logo */}
      <div style={{ transform: `scale(${logoScale})`, marginBottom: 50 }}>
        <ClaudeLogo size={170} glowIntensity={0.75} />
      </div>

      <div style={{ transform: `translateY(${titleY}px)`, opacity: titleOpacity, textAlign: "center" }}>
        <div style={{ fontSize: 72, fontFamily: "'Georgia', serif", color: "#FFFFFF", fontWeight: 700, letterSpacing: 4 }}>
          Meet Claude
        </div>
      </div>

      <div style={{ opacity: subtitleOpacity, textAlign: "center", marginTop: 20 }}>
        <div style={{ fontSize: 30, fontFamily: "'Georgia', serif", color: "rgba(232,184,154,0.85)", fontWeight: 300, letterSpacing: 3 }}>
          Your intelligent AI companion
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 80, left: "50%", transform: "translateX(-50%)", opacity: voiceOpacity, textAlign: "center", maxWidth: 900 }}>
        <div style={{ fontSize: 24, fontFamily: "'Georgia', serif", color: "rgba(255,255,255,0.5)", fontStyle: "italic", letterSpacing: 1 }}>
          "Imagine having an AI that thinks alongside you..."
        </div>
      </div>
    </AbsoluteFill>
  );
};
