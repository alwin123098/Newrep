import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate } from "remotion";
import { Particles } from "../Particles";
import { ClaudeLogo } from "../ClaudeLogo";

const messages = [
  { role: "user", text: "Help me write a poem about the ocean." },
  { role: "claude", text: "The waves whisper secrets to the shore,\nIn rhythms older than any lore..." },
  { role: "user", text: "Can you explain quantum entanglement?" },
  { role: "claude", text: "Two particles, linked across any distance — measure one, and you instantly know the other." },
];

export const SceneChat: React.FC = () => {
  const frame = useCurrentFrame();
  const titleOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: "radial-gradient(ellipse at 60% 40%, #150b07 0%, #060302 100%)", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      <Particles />
      <div style={{ opacity: titleOpacity, marginBottom: 48, textAlign: "center" }}>
        <div style={{ fontSize: 44, fontFamily: "'Georgia', serif", color: "#CC785C", letterSpacing: 4, textTransform: "uppercase" }}>
          Real Conversations
        </div>
      </div>

      <div style={{
        width: 860,
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(204,120,92,0.25)",
        borderRadius: 28,
        padding: "32px 40px",
        boxShadow: "0 20px 80px rgba(0,0,0,0.6)",
      }}>
        {/* Title bar */}
        <div style={{ display: "flex", alignItems: "center", marginBottom: 28, gap: 10 }}>
          <div style={{ width: 12, height: 12, borderRadius: "50%", background: "#CC785C" }} />
          <div style={{ width: 12, height: 12, borderRadius: "50%", background: "rgba(204,120,92,0.4)" }} />
          <div style={{ width: 12, height: 12, borderRadius: "50%", background: "rgba(204,120,92,0.2)" }} />
          <div style={{ marginLeft: "auto", fontSize: 16, color: "rgba(255,255,255,0.3)", fontFamily: "'Georgia', serif" }}>claude.ai</div>
        </div>

        {messages.map((msg, i) => {
          const msgOpacity = interpolate(frame, [15 + i * 18, 30 + i * 18], [0, 1], { extrapolateRight: "clamp" });
          const msgX = interpolate(frame, [15 + i * 18, 28 + i * 18], [msg.role === "user" ? 30 : -30, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
          const isUser = msg.role === "user";
          return (
            <div key={i} style={{ display: "flex", justifyContent: isUser ? "flex-end" : "flex-start", marginBottom: 20, opacity: msgOpacity, transform: `translateX(${msgX}px)` }}>
              {!isUser && (
                <div style={{ marginRight: 14, flexShrink: 0, marginTop: 2 }}>
                  <ClaudeLogo size={40} glowIntensity={0.4} />
                </div>
              )}
              <div style={{
                maxWidth: "72%",
                background: isUser ? "rgba(204,120,92,0.2)" : "rgba(255,255,255,0.06)",
                border: `1px solid ${isUser ? "rgba(204,120,92,0.4)" : "rgba(255,255,255,0.1)"}`,
                borderRadius: isUser ? "20px 20px 4px 20px" : "20px 20px 20px 4px",
                padding: "14px 20px",
              }}>
                <div style={{ fontSize: 18, fontFamily: "'Georgia', serif", color: isUser ? "#F0CDB8" : "rgba(255,255,255,0.82)", lineHeight: 1.6, whiteSpace: "pre-line" }}>{msg.text}</div>
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
