import "./index.css";
import { Composition } from "remotion";
import { ClaudeAd } from "./ClaudeAd";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ClaudeAd"
        component={ClaudeAd}
        durationInFrames={900}
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
